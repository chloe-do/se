package controller;

import com.alibaba.excel.EasyExcel;
import dbutil.Dbconn;
import entity.User;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

public class UploadController extends HttpServlet {

    private PreparedStatement ps;
    private ResultSet rs;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp){
        DiskFileItemFactory factory=new DiskFileItemFactory();
        ServletFileUpload upload =new ServletFileUpload(factory);
        try {
            FileItem fileItem = upload.parseRequest(req).get(0);
            List<User> list = null;
            list = EasyExcel.read(fileItem.getInputStream()).head(User.class).sheet().doReadSync();
            Dbconn s=new Dbconn();
            for (User user : list) {
                Connection conn=s.getConnection();
                String sql="insert user values(?,?,?)";
                ps=conn.prepareStatement(sql);
                ps.setInt(1, user.getId());
                ps.setString(2, user.getName());
                ps.setString(3, user.getPassword());
                ps.executeUpdate();
                s.closeAll(conn,ps,rs);
            }
            resp.getWriter().write("upload excel success~");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
